// Script called on Calculator form sumit
$(document).ready(function() {
    $(document).on('submit', function() {

      var costPrice = parseInt($("#id_sharesCP").val());
      var sellPrice = parseInt($("#id_sharesSP").val());
      var noShare = parseInt($("#id_sharesNo").val());

      // var rates = loadXMLDoc();
      // var rates = setTimeout((function(){
      //     $.ajax({
      //       'url': "../assets/data/rate.json",
      //       'type':'GET',
      //       'crossDomain':true,
      //       'dataType': "jsonp",
      //       'jsonpCallback': 'callback',
      //       'success': function (data) {
      //           return data;
      //       }
      //     })
      // })(), 2000);

      // console.log(rates);

      var totalTurnOver = calculateTurnOver(costPrice,sellPrice,noShare);
      var brokrage = calculateBrokrage(totalTurnOver,0.0001);
      var stt = calculateSTT(costPrice,sellPrice,0.1);
      var sebiCharge = calculateSEBICharge(costPrice,sellPrice,0.0002);
      var transactionCharge = calculateTransactionCharge(costPrice,sellPrice,0.00325);
      var gst = calculateGST(brokrage,0.18);
      var totalBrokrageValue = calculateTotalBrokrage(brokrage,stt,sebiCharge,transactionCharge,gst);
      var totalProfit = calculateTotalProfit(costPrice,sellPrice,noShare,totalBrokrageValue);

      $("#id_totalTurnOver").text(totalTurnOver.toFixed(2));
      $("#id_brokerage").text(brokrage.toFixed(2));
      $("#id_STT").text(stt.toFixed(2));
      $("#id_SEBITurnOverCharge").text(sebiCharge.toFixed(2));
      $("#id_TransactionCharge").text(transactionCharge.toFixed(2));
      $("#id_GST").text(gst.toFixed(2));
      $("#id_TotalBrokerageTax").text(totalBrokrageValue.toFixed(2));
      $("#id_TotalProfit").text(totalProfit.toFixed(2));

      return false;
     });
});

function calculateTurnOver(costPrice,sellPrice,noShare) {
  return parseFloat((costPrice+sellPrice)*noShare);
}

function calculateBrokrage(turnover,brokrageRate) {
  return parseFloat(brokrageRate * turnover);
}

function calculateSTT(costPrice,sellPrice,sttRate){
  return parseFloat((costPrice + sellPrice) * sttRate);
}

function calculateSEBICharge(costPrice,sellPrice,sebiCharge){
  return parseFloat((costPrice + sellPrice) * sebiCharge);
}

function calculateTransactionCharge(costPrice,sellPrice,transactionCharge){
  return parseFloat((costPrice + sellPrice) * transactionCharge);
}

function calculateGST(totalBrokrage,gstRate){
  return parseFloat(totalBrokrage * gstRate);
}

function calculateTotalBrokrage(brokrage,stt,sebiCharge,transactionCharge,gst){
  return parseFloat(brokrage + stt + sebiCharge + transactionCharge + gst);
}

function calculateTotalProfit(costPrice,sellPrice,noShare,totalBrokrage){
  return parseFloat(((sellPrice - costPrice) * noShare) - totalBrokrage);
}

// function loadXMLDoc() {
//   var xmlhttp = new XMLHttpRequest();
//   xmlhttp.onreadystatechange = function() {
//     if (this.readyState == 4 && this.status == 200) {
//       console.log(this);
//     }
//   };
//   xmlhttp.open("GET", "../assets/data/rate.json", true);
//   xmlhttp.send();
// }
